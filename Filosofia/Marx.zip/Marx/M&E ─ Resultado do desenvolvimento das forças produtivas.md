---
Date: Sunday, 20-06-2021 @ 17:03
Tags: marxism
---
# Resultado do desenvolvimento das forças produtivas
1. Surgem forças produtivas e meios de intercâmbio que passam a causar somente malefícios, pervertendo-se em **forças de destruição**, as quais criam uma **classe massiva** que é despojada/**[[M&E ─ Surgimento da alienação|alienada]]** dos produtos de seu trabalho e que é forçada a "suportar todos os fardos da sociedade **sem desfrutar de suas vantagens**".
2. As condições de uso desses meios de produção se acumularam nas mãos de poucos, da **classe dominante**.
(Isso determina porque toda luta proletária deve se dar **contra a classe dominante**: devido a essa [[M&E ─ Ideologia da classe dominante|"coincidência"]] de posse dos meios de produção com essa classe)
3. A revolução **comunista** destaca-se das demais revoluções prévias por buscar modificar a "**forma** da atividade existente até então", suprimir o **trabalho** (sob dominação/alienado) e **superar a dominação de todas as classes** (por ser levada a cabo por uma massa da população que não pode mais ser caracterizada por "classe").
4. É necessária uma **revolução**, um **movimento prático** para obter-se a consciência comunista e para se ter a oportunidade de "**desembaraçar-se de toda a antiga imundície**" da antiga classe dominante. 

---
### References
- MARX, Karl; ENGELS, Friedrich. **A ideologia alemã**. Boitempo Editorial, 2015.