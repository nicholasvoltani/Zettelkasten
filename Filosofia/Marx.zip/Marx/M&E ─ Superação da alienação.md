---
Date: Wednesday, 02-06-2021 @ 18:22
Source:
Tags: marxism
---
# Superação da alienação (universal), segundo Marx e Engels
N'[[A Ideologia Alemã]], Marx e Engels elaboram que são necessários três pressupostos a fim de se superar a [[M&E ─ Surgimento da alienação|alienação]]:
1. Que esse poder alienante deixe a "massa da humanidade '**sem propriedade**'", em meio a todas as riquezas por ela produzida por seu trabalho; 
2. Necessita-se que as **forças de produção sejam elevadas o suficiente** a fim de que a sublevação do poder alheio não os atire de volta à carestia;
3. Que seja uma superação **internacional**, posto que este poder alheio também o é/busca ser


---
### References
- MARX, Karl; ENGELS, Friedrich. **A ideologia alemã**. Boitempo Editorial, 2015.