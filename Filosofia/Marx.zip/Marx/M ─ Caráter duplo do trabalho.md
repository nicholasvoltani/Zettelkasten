---
Date: Monday, 09-08-2021 @ 22:23
Tags: marxism
---
# O caráter duplo do trabalho, segundo Marx
* Trabalho **concreto**: responsável pela criação de **valores de uso** específicos: o [[M ─ Trabalho|trabalho]] para a confecção de um casaco de linho é diferente daquele para a confecção de um navio; 
* Trabalho **abstrato**: considerado como somente o tempo médio levado pelo dispêndio de força humana indistinta para a confecção de alguma mercadoria, criador de **valor**.  


---
### References
- MARX, Karl. **O capital-Livro 1: Crítica da economia política. Livro 1: O processo de produção do capital**. Boitempo Editorial, 2013.