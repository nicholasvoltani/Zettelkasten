---
Date: Wednesday, 02-06-2021 @ 18:22
Source:
Tags: marxism
---
# Surgimento da alienação [*Entfremdung*], segundo Marx e Engels
N'[[A Ideologia Alemã]], Marx e Engels elaboram que, quando o trabalho não é dividido de forma **voluntária**, e sim de forma **natural** (no sentido de *natureza*, *nascimento*), a ação do homens se lhes parecerá um **poder estranho**, cujo objetivo lhes é desconhecido e o qual pode até mesmo "usar-lhes como meio para tal", tornando-se incontrolável por eles. 

Um exemplo é o da divisão rígida de trabalho, onde os papeis de cada indivíduo será o mesmo até sua morte, e que estes deverão cumprir se quiserem ter seu sustento; outro exemplo é o da ideia da Mão Invisível de Smith, que é o poder alheio do mercado, que materialmente nada mais é senão o intercâmbio entre os homens, mas que ainda assim se lhes aparenta ser *estranho*.

---
### References
- MARX, Karl; ENGELS, Friedrich. **A ideologia alemã**. Boitempo Editorial, 2015.